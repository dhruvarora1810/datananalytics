-- Replace ${datahub_table} is substituted automatically from config.properties DATAHUB_TABLE value
-- Modify the WHERE clause and columns as needed for your use case
SELECT *
FROM ${datahub_table}
WHERE audit_load_dt = 20260129
LIMIT 10
