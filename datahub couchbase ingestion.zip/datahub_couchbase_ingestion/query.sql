-- Edit this query directly with your table name and filters
SELECT *
FROM gcgdlknapsg_fiserv_t_db.accb_ovvr_daily_crs_mcy
WHERE audit_load_dt = 20260129
LIMIT 10
