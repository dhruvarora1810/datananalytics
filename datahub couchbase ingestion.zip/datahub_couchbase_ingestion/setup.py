from setuptools import setup, find_packages

setup(
    name="datahub-couchbase-ingestion",
    version="1.0.0",
    description="Spark-based ingestion pipeline from Hadoop/Hive to Couchbase via YARN",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "pyspark",
    ],
    entry_points={
        "console_scripts": [
            "datahub-couchbase-ingest=datahub_couchbase_ingestion.couchbase_ingestion_common:main",
        ]
    },
    include_package_data=True,
    package_data={
        "": ["*.properties", "*.sql", "*.pem", "*.jar"],
    },
)
