#!/bin/bash
# ============================================================
# run.sh - Submit the Couchbase ingestion job to YARN
# Usage: ./run.sh [--operation insert|upsert|delete]
# Requires: COUCHBASE_PASSWORD environment variable to be set
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="${SCRIPT_DIR}/config.properties"
QUERY="${SCRIPT_DIR}/query.sql"
PEM="${SCRIPT_DIR}/Citi_DEVELOPMENT_chain.pem"
JAR="${SCRIPT_DIR}/spark-connector-assembly-3.3.7.jar"
MAIN="${SCRIPT_DIR}/datahub_couchbase_ingestion/couchbase_ingestion_common.py"

if [ -z "$COUCHBASE_PASSWORD" ]; then
  echo "ERROR: COUCHBASE_PASSWORD environment variable is not set."
  exit 1
fi

spark3-submit \
  --master yarn \
  --deploy-mode client \
  --conf spark.yarn.queue=root.analyst \
  --jars "${JAR}" \
  --files "${PEM}" \
  --conf spark.pyspark.python=/usr/bin/python3 \
  --conf spark.pyspark.driver.python=/usr/bin/python3 \
  "${MAIN}" "${CONFIG}" "$@"
