# DataHub Couchbase Ingestion

PySpark pipeline that reads data from Hive/Hadoop and writes it to Couchbase, running on YARN.

## Package Structure

```
datahub_couchbase_ingestion/
├── datahub_couchbase_ingestion/
│   ├── __init__.py
│   └── couchbase_ingestion_common.py   # Main ingestion logic
├── config.properties                    # ← Edit this for your environment
├── query.sql                            # ← Edit this for your data
├── Citi_DEVELOPMENT_chain.pem           # TLS certificate (do not commit)
├── spark-connector-assembly-3.3.7.jar   # Couchbase Spark connector
├── run.sh                               # Convenience submit script
├── setup.py
└── README.md
```

## Prerequisites

- Python 3.6+
- Spark 3.x with YARN
- Access to Couchbase cluster
- `Citi_DEVELOPMENT_chain.pem` certificate file
- `spark-connector-assembly-3.3.7.jar`

## Setup

1. Clone/copy this package to your node
2. Edit `config.properties` with your table and settings
3. Edit `query.sql` with your Hive query
4. Set the password environment variable:
   ```bash
   export COUCHBASE_PASSWORD="your_password_here"
   ```

## Running

### Using the convenience script (recommended)
```bash
chmod +x run.sh
./run.sh
```

### With a specific operation
```bash
./run.sh --operation upsert   # default
./run.sh --operation insert
./run.sh --operation delete
```

### Manual spark-submit
```bash
spark3-submit \
  --master yarn \
  --deploy-mode client \
  --conf spark.yarn.queue=root.analyst \
  --jars spark-connector-assembly-3.3.7.jar \
  --files Citi_DEVELOPMENT_chain.pem \
  --conf spark.pyspark.python=/usr/bin/python3 \
  --conf spark.pyspark.driver.python=/usr/bin/python3 \
  datahub_couchbase_ingestion/couchbase_ingestion_common.py config.properties
```

## Configuration Reference

| Parameter | Description |
|-----------|-------------|
| `APP_NAME` | Spark application name shown in YARN UI |
| `SPARK_PARTITIONS` | Number of Spark partitions (default: 16) |
| `COUCHBASE_CONN_STRING` | Couchbase connection string |
| `COUCHBASE_USERNAME` | Service account username |
| `COUCHBASE_BUCKET` | Target bucket name |
| `COUCHBASE_SCOPE` | Scope (use `_default` if not applicable) |
| `COUCHBASE_COLLECTION` | Collection (use `_default` if not applicable) |
| `CERT` | Certificate filename (just filename when running on YARN) |
| `DATAHUB_TABLE` | Hive table to read from |
| `QUERIES_FILE` | Path to SQL file |
| `COUCHBASE_KEY_CONST` | Column to use as document key |
| `OPERATION` | `insert`, `upsert`, or `delete` |
| `JAR_PATH` | Path to Couchbase Spark connector JAR |
