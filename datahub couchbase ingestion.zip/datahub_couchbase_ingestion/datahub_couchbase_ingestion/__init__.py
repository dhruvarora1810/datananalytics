from .couchbase_ingestion_common import main, load_config, AppConfig

__version__ = "1.0.0"
__all__ = ["main", "load_config", "AppConfig"]
