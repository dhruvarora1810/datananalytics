import argparse
import configparser
import logging
import os
import sys
from dataclasses import dataclass
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import StringType

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


@dataclass
class AppConfig:
    spark_app_name: str
    connection_string: str
    username: str
    password: str
    bucket_name: str
    scope_name: str
    collection_name: str
    cert_path: str
    query_file: str
    key_const: str
    partitions: int
    operation: str
    jar_path: str


def load_config(config_file, password, operation):
    props = configparser.ConfigParser()
    props.read(config_file)
    d = props["DEFAULT"]
    cert = d.get("CERT", "")
    final_op = operation if operation else d.get("OPERATION", "upsert")
    return AppConfig(
        spark_app_name=d.get("APP_NAME"),
        connection_string=d.get("COUCHBASE_CONN_STRING"),
        username=d.get("COUCHBASE_USERNAME"),
        password=password,
        bucket_name=d.get("COUCHBASE_BUCKET"),
        scope_name=d.get("COUCHBASE_SCOPE", ""),
        collection_name=d.get("COUCHBASE_COLLECTION", ""),
        cert_path=cert if cert else None,
        query_file=d.get("QUERIES_FILE"),
        key_const=d.get("COUCHBASE_KEY_CONST", ""),
        partitions=d.getint("SPARK_PARTITIONS", 16),
        operation=final_op,
        jar_path=d.get("JAR_PATH", "spark-connector-assembly-3.3.7.jar"),
    )


def main():
    password = os.environ.get("COUCHBASE_PASSWORD")
    if not password:
        logger.error("COUCHBASE_PASSWORD not set.")
        sys.exit(1)

    parser = argparse.ArgumentParser()
    parser.add_argument("config_file")
    parser.add_argument("--operation", choices=["insert", "upsert", "delete"], default=None)
    args = parser.parse_args()

    config = load_config(args.config_file, password, args.operation)

    builder = (
        SparkSession.builder
        .appName(config.spark_app_name)
        .config("spark.couchbase.connectionString", config.connection_string)
        .config("spark.couchbase.username", config.username)
        .config("spark.couchbase.password", password)
        .config("spark.couchbase.implicitBucket", config.bucket_name)
        .config("spark.jars", config.jar_path)
        .config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
    )

    if config.cert_path:
        builder = builder.config("spark.couchbase.security.trustCertificate", config.cert_path)

    spark = builder.enableHiveSupport().getOrCreate()

    try:
        with open(config.query_file, "r") as f:
            sql = f.read()
        logger.info("Running query: {}".format(sql))
        df = spark.sql(sql)
        df2 = df.select([col(c).cast(StringType()) for c in df.columns])
        count = df2.count()
        logger.info("Loaded {} records.".format(count))

        if count == 0:
            logger.info("No records found.")
            spark.stop()
            return

        key_col = config.key_const if config.key_const else df2.columns[0]
        logger.info("Using key column: {}".format(key_col))
        df_batch = df2.withColumn("key_column", col(key_col))

        write_opts = {
            "bucket": config.bucket_name,
            "idFieldName": "key_column",
        }
        if config.scope_name:
            write_opts["scope"] = config.scope_name
        if config.collection_name:
            write_opts["collection"] = config.collection_name

        if config.operation == "delete":
            df_batch.select("key_column").write.format("couchbase.kv") \
                .options(**write_opts) \
                .option("operation", "delete") \
                .mode("overwrite") \
                .save()
        else:
            df_batch.write.format("couchbase.kv") \
                .options(**write_opts) \
                .mode("overwrite") \
                .save()

        logger.info("DONE! {} completed successfully.".format(config.operation))
        spark.stop()

    except Exception as e:
        logger.error("Job failed: {}".format(e), exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
